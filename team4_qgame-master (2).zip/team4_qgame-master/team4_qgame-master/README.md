#team4_qgame

being honest I don't really undertand what I'm doing, but I hope everything will be fine.
А про гру чесно кажучи, покищо додати нічого. думаю більше думок буде з'являтися під час активної роботи над нею.  (с)Остап