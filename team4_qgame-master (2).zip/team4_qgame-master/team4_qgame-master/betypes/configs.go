package betypes

const (
	BOT_TOKEN = "{HERE_WILL_BE_YOUR_BOT_TOKEN}" //Your bot token
	//TELEGRAM_URL = "https://api.telegram.org/bot"
	BOT_PORT = "8090"
	WEB_HOOK = "{NGROK_URL}" //Ngrok url
)
